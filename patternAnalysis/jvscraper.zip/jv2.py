
import re
import sys
import time
import getpass
from texttable import Texttable
from selenium import webdriver
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.firefox.firefox_binary import FirefoxBinary
from selenium.common.exceptions import *

#check if an topic link  is given in param of our program
if len(sys.argv) < 3:
    print("Error! Usage: python3 jv.py link_to_topic output_file_name")
    sys.exit(1)

#get the topic link from sysarg
tpclink = sys.argv[1]
filename = sys.argv[2]

#init driver and browser
firefox_dev_binary = FirefoxBinary(r'/Applications/Firefox Developer Edition.app/Contents/MacOS/firefox-bin')
driver = webdriver.Firefox(firefox_binary=firefox_dev_binary, executable_path="geckodriver")

#open link
driver.get(tpclink)

#vars needed
hasNextPage=1
pages=1
messages = 0
#print the topic TITLE
titleElm = driver.find_element_by_xpath("//span[@id='bloc-title-forum']")
title = titleElm.text
f = open(filename+".xml", "w")
f.write('<document title="' + title + '">')
#while the topic has pages
while hasNextPage != 0:
    #get all msgs
    msgs = driver.find_elements_by_xpath("//div[@class='txt-msg  text-enrichi-forum ']")
    #print all msg

    for msg in msgs :
        f.write("<msg id='" + str(messages) + "'> " + msg.text )
        f.write("</msg>")
        messages+=1
    #check if there is a next page
    try:
        next = driver.find_element_by_xpath("//a[@class='xXx pagi-suivant-actif']")
        driver.execute_script("arguments[0].click();", next)
        pages+=1
        time.sleep(1)
    except NoSuchElementException:
        f.write('</document>')
        hasNextPage = 0
